// Section 6.4: different IPTV panels expose different APIs. Every adapter
// implements this same interface so the rest of the app (backend AND the
// customer Player App, Section 3.4) only ever talks to one integration
// point regardless of which panel type a given server uses.
export interface CreateLoginParams {
  macAddress: string;
  months: number | null; // null = trial
}

export interface CreateLoginResult {
  success: boolean;
  streamUrl?: string;
  panelUsername?: string; // for Xtream-style panels
  error?: string;
}

export interface PanelAdapter {
  createLogin(params: CreateLoginParams): Promise<CreateLoginResult>;
  removeLogin(macAddress: string): Promise<void>;
  rebindMacAddress(oldMac: string, newMac: string): Promise<void>;
  getConnectionCount(): Promise<number>;
}
