import { Injectable } from '@nestjs/common';
import { Server, PanelType } from '../server.entity';
import { PanelAdapter } from './panel-adapter.interface';
import { XtreamCodesAdapter } from './xtream-codes.adapter';
import { StalkerMinistraAdapter } from './stalker-ministra.adapter';

// Section 6.4: one factory, one place that decides which adapter runs for
// a given server. Adding a new panel type later means adding one class
// here and one enum value — nothing else in the app changes.
@Injectable()
export class PanelAdapterFactory {
  create(server: Server, decryptedCredentials: Record<string, string>): PanelAdapter {
    switch (server.panelType) {
      case PanelType.XTREAM_CODES:
        return new XtreamCodesAdapter(server.hostUrl, decryptedCredentials);
      case PanelType.STALKER_MINISTRA:
        return new StalkerMinistraAdapter(server.hostUrl, decryptedCredentials);
      case PanelType.CUSTOM:
      default:
        throw new Error(
          `No adapter implemented for panel type "${server.panelType}". Add one in panel-adapters/.`,
        );
    }
  }
}
