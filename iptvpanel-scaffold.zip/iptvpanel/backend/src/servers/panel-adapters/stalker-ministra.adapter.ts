import { PanelAdapter, CreateLoginParams, CreateLoginResult } from './panel-adapter.interface';

// Same idea as XtreamCodesAdapter — swap in real Stalker/Ministra
// portal API calls. MAC-address-based panels typically create/bind a
// subscriber record keyed directly on macAddress.
export class StalkerMinistraAdapter implements PanelAdapter {
  constructor(private hostUrl: string, private apiCredentials: Record<string, string>) {}

  async createLogin(params: CreateLoginParams): Promise<CreateLoginResult> {
    throw new Error('StalkerMinistraAdapter.createLogin: integrate with your panel API here.');
  }

  async removeLogin(macAddress: string): Promise<void> {
    throw new Error('StalkerMinistraAdapter.removeLogin: integrate with your panel API here.');
  }

  async rebindMacAddress(oldMac: string, newMac: string): Promise<void> {
    throw new Error('StalkerMinistraAdapter.rebindMacAddress: integrate with your panel API here.');
  }

  async getConnectionCount(): Promise<number> {
    throw new Error('StalkerMinistraAdapter.getConnectionCount: integrate with your panel API here.');
  }
}
