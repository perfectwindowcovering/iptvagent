import { PanelAdapter, CreateLoginParams, CreateLoginResult } from './panel-adapter.interface';

// Fill in with real Xtream Codes API calls (line/user management endpoints
// for the specific panel software your upstream servers run). Kept as a
// clearly-marked stub so the rest of the codebase (approval workflow,
// customer player app) can be built and tested against the interface now.
export class XtreamCodesAdapter implements PanelAdapter {
  constructor(private hostUrl: string, private apiCredentials: Record<string, string>) {}

  async createLogin(params: CreateLoginParams): Promise<CreateLoginResult> {
    throw new Error('XtreamCodesAdapter.createLogin: integrate with your panel API here.');
  }

  async removeLogin(macAddress: string): Promise<void> {
    throw new Error('XtreamCodesAdapter.removeLogin: integrate with your panel API here.');
  }

  async rebindMacAddress(oldMac: string, newMac: string): Promise<void> {
    throw new Error('XtreamCodesAdapter.rebindMacAddress: integrate with your panel API here.');
  }

  async getConnectionCount(): Promise<number> {
    throw new Error('XtreamCodesAdapter.getConnectionCount: integrate with your panel API here.');
  }
}
