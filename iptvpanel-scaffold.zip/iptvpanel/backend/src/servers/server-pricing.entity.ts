import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn, Unique } from 'typeorm';
import { Server } from './server.entity';

// Section 2.1 / 6.2: business sets a fixed rate per plan duration,
// optionally varying by server since supplier cost may differ.
@Entity('server_pricing')
@Unique(['server', 'months'])
export class ServerPricing {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => Server, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'server_id' })
  server: Server;

  @Column({ name: 'server_id', type: 'uuid' })
  serverId: string;

  // 0 = trial pricing (usually free/zero), 1-60 = month count.
  @Column({ type: 'int' })
  months: number;

  @Column({ name: 'fixed_rate', type: 'decimal', precision: 10, scale: 2 })
  fixedRate: string;

  @Column({ default: 'USD' })
  currency: string;
}
