import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
} from 'typeorm';

// Section 6.1: different upstream IPTV panels expose different APIs.
// panelType determines which adapter (Section 6.4) handles login creation.
export enum PanelType {
  XTREAM_CODES = 'xtream_codes',
  STALKER_MINISTRA = 'stalker_ministra',
  CUSTOM = 'custom',
}

export enum ServerStatus {
  ACTIVE = 'active',
  INACTIVE = 'inactive',
  MAINTENANCE = 'maintenance',
}

@Entity('servers')
export class Server {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  name: string;

  @Column({ name: 'panel_type', type: 'enum', enum: PanelType })
  panelType: PanelType;

  @Column({ name: 'host_url' })
  hostUrl: string;

  // Encrypted at rest — see Section 11.3. Never exposed to agent/customer
  // accounts or serialized to the frontend (excluded via class-transformer
  // in the controller response DTO).
  @Column({ name: 'api_credentials_encrypted', type: 'text' })
  apiCredentialsEncrypted: string;

  @Column({ name: 'max_connections', type: 'int' })
  maxConnections: number;

  @Column({ name: 'current_connections', type: 'int', default: 0 })
  currentConnections: number;

  @Column({ type: 'enum', enum: ServerStatus, default: ServerStatus.ACTIVE })
  status: ServerStatus;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}
