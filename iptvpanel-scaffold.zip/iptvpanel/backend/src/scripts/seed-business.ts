import 'dotenv/config';
import { AppDataSource } from '../data-source';
import { User, UserRole, UserStatus } from '../users/user.entity';
import { AuthService } from '../auth/auth.service';

// Section 2.1: the business account isn't created through the API — it's
// the root account, seeded once. Run with: npx ts-node src/scripts/seed-business.ts
async function main() {
  const phone = process.env.SEED_BUSINESS_PHONE ?? '+10000000000';
  const password = process.env.SEED_BUSINESS_PASSWORD;
  if (!password) {
    throw new Error('Set SEED_BUSINESS_PASSWORD before running the seed script.');
  }

  await AppDataSource.initialize();
  const repo = AppDataSource.getRepository(User);

  const existing = await repo.findOne({ where: { phone } });
  if (existing) {
    console.log('Business account already exists for', phone);
    await AppDataSource.destroy();
    return;
  }

  const business = repo.create({
    role: UserRole.BUSINESS,
    businessId: null,
    phone,
    name: 'Business Admin',
    passwordHash: await AuthService.hashPassword(password),
    status: UserStatus.ACTIVE,
  });
  await repo.save(business);

  console.log('Business account created:', phone);
  console.log('Remember to enable 2FA on first login (Section 11.1).');
  await AppDataSource.destroy();
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
