import { IsString, MinLength, IsOptional } from 'class-validator';

export class LoginDto {
  @IsString()
  phone: string;

  @IsString()
  @MinLength(8)
  password: string;

  // Required on the second call once the server responds
  // "2FA code required" (Section 11.1).
  @IsOptional()
  @IsString()
  twoFactorCode?: string;
}
