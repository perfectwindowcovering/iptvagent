import {
  Injectable,
  UnauthorizedException,
  ForbiddenException,
  BadRequestException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcrypt';
import { User, UserStatus } from '../users/user.entity';
import { LoginDto } from './dto/login.dto';

const BCRYPT_ROUNDS = 12;
const MAX_FAILED_ATTEMPTS = 5;
const LOCKOUT_WINDOW_MINUTES = 15;

// Section 11.1: Authentication & Login.
// - passwords hashed with bcrypt (never plain text / reversible encryption)
// - rate-limiting + temporary lockout after repeated failed attempts
// - 2FA required for business and agent accounts
//
// NOTE: failed-attempt tracking below uses a simple in-memory map for
// clarity. In production, back this with Redis (or a DB table) so it
// survives restarts and works across multiple server instances.
@Injectable()
export class AuthService {
  private failedAttempts = new Map<string, { count: number; lockedUntil: number | null }>();

  constructor(
    @InjectRepository(User) private usersRepo: Repository<User>,
    private jwt: JwtService,
  ) {}

  static async hashPassword(plain: string): Promise<string> {
    return bcrypt.hash(plain, BCRYPT_ROUNDS);
  }

  private checkLockout(phone: string) {
    const entry = this.failedAttempts.get(phone);
    if (entry?.lockedUntil && entry.lockedUntil > Date.now()) {
      const secondsLeft = Math.ceil((entry.lockedUntil - Date.now()) / 1000);
      throw new ForbiddenException(
        `Too many failed attempts. Try again in ${secondsLeft} seconds.`,
      );
    }
  }

  private registerFailedAttempt(phone: string) {
    const entry = this.failedAttempts.get(phone) ?? { count: 0, lockedUntil: null };
    entry.count += 1;
    if (entry.count >= MAX_FAILED_ATTEMPTS) {
      entry.lockedUntil = Date.now() + LOCKOUT_WINDOW_MINUTES * 60 * 1000;
      entry.count = 0;
      // Section 11.5: alert on suspicious patterns — wire this into your
      // notification/monitoring pipeline (e.g. emit an event here).
    }
    this.failedAttempts.set(phone, entry);
  }

  private clearFailedAttempts(phone: string) {
    this.failedAttempts.delete(phone);
  }

  async login(dto: LoginDto) {
    this.checkLockout(dto.phone);

    const user = await this.usersRepo.findOne({
      where: { phone: dto.phone },
      select: ['id', 'role', 'businessId', 'passwordHash', 'status', 'twoFactorEnabled', 'twoFactorSecret'],
    });

    // Same generic error whether the phone doesn't exist or the password is
    // wrong — do not reveal which, to avoid account enumeration.
    const genericError = () => {
      this.registerFailedAttempt(dto.phone);
      throw new UnauthorizedException('Invalid phone number or password.');
    };

    if (!user) return genericError();
    if (user.status === UserStatus.SUSPENDED) {
      throw new ForbiddenException('This account has been suspended.');
    }

    const passwordOk = await bcrypt.compare(dto.password, user.passwordHash);
    if (!passwordOk) return genericError();

    if (user.twoFactorEnabled) {
      if (!dto.twoFactorCode) {
        // Client should re-submit with twoFactorCode filled in.
        return { twoFactorRequired: true };
      }
      const codeOk = this.verifyTwoFactorCode(user.twoFactorSecret!, dto.twoFactorCode);
      if (!codeOk) return genericError();
    }

    this.clearFailedAttempts(dto.phone);
    return this.issueTokens(user);
  }

  private verifyTwoFactorCode(secret: string, code: string): boolean {
    // Plug in a TOTP library here, e.g.:
    //   import { authenticator } from 'otplib';
    //   return authenticator.check(code, secret);
    throw new BadRequestException(
      'Two-factor verification is not wired up yet — integrate otplib (or similar) here.',
    );
  }

  private issueTokens(user: Pick<User, 'id' | 'role' | 'businessId'>) {
    const payload = { sub: user.id, role: user.role, businessId: user.businessId };
    return {
      accessToken: this.jwt.sign(payload, { expiresIn: process.env.JWT_ACCESS_EXPIRES_IN ?? '15m' }),
      refreshToken: this.jwt.sign(payload, {
        secret: process.env.JWT_REFRESH_SECRET,
        expiresIn: process.env.JWT_REFRESH_EXPIRES_IN ?? '7d',
      }),
    };
  }
}
