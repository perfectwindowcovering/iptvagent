import { SetMetadata } from '@nestjs/common';
import { UserRole } from '../users/user.entity';

export const ROLES_KEY = 'roles';

// Section 11.2: authorization is enforced here, on every guarded route —
// never left to the frontend to hide a button. Usage:
//   @Roles(UserRole.BUSINESS)
//   @UseGuards(JwtAuthGuard, RolesGuard)
export const Roles = (...roles: UserRole[]) => SetMetadata(ROLES_KEY, roles);
