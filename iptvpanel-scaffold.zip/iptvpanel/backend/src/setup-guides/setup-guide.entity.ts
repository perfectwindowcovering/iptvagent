import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  UpdateDateColumn,
} from 'typeorm';
import { User } from '../users/user.entity';

export enum GuideStatus {
  ACTIVE = 'active',
  INACTIVE = 'inactive',
}

// Section 9: PDF setup-instruction library. Admin-managed; agents can
// view/download and attach to a customer record but cannot edit (Section 9.2).
@Entity('setup_guides')
export class SetupGuide {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  title: string;

  @Column({ name: 'device_model' })
  deviceModel: string; // e.g. 'Android Box', 'Firestick', 'Smart TV App', 'MAG Box'

  @Column({ name: 'file_url' })
  fileUrl: string; // storage URL/key for the PDF

  @Column({ default: 1 })
  version: number;

  @Column({ type: 'enum', enum: GuideStatus, default: GuideStatus.ACTIVE })
  status: GuideStatus;

  @ManyToOne(() => User)
  @JoinColumn({ name: 'uploaded_by' })
  uploadedBy: User;

  @Column({ name: 'uploaded_by', type: 'uuid' })
  uploadedById: string;

  @UpdateDateColumn({ name: 'updated_date' })
  updatedDate: Date;
}
