import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  CreateDateColumn,
  UpdateDateColumn,
  Index,
} from 'typeorm';
import { User } from '../users/user.entity';
import { Server } from '../servers/server.entity';

export enum PlanType {
  TRIAL = 'trial',
  MONTH = 'month',
}

export enum CustomerStatus {
  PENDING = 'pending', // awaiting business approval (Section 4)
  ACTIVE = 'active',
  EXPIRED = 'expired',
  SUSPENDED = 'suspended',
}

// Section 4 data model + Section 3 (Customer Account / Player App).
// One row = one customer's IPTV login, bound to exactly one server and one
// device (Section 3.3 — single-device MAC binding, no concurrent streams).
@Entity('customers')
export class Customer {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  // The agent who added this customer. Agents can only query their own
  // customers — enforced in the service layer, not just the UI (Section 11.2).
  @ManyToOne(() => User)
  @JoinColumn({ name: 'agent_id' })
  agent: User;

  @Column({ name: 'agent_id', type: 'uuid' })
  @Index()
  agentId: string;

  @ManyToOne(() => Server)
  @JoinColumn({ name: 'server_id' })
  server: Server;

  @Column({ name: 'server_id', type: 'uuid' })
  serverId: string;

  @Column()
  name: string;

  @Column()
  phone: string;

  // Customer's own login for the Player App (Section 3.1) reuses this
  // phone + a password hash — see CustomerAuthService.
  @Column({ name: 'password_hash' })
  passwordHash: string;

  // Bound to exactly one device (Section 3.3). Format depends on panel type:
  // MAC address for Stalker/Ministra, or a generated username for Xtream Codes.
  @Column({ name: 'mac_address', unique: true })
  macAddress: string;

  @Column({ name: 'plan_type', type: 'enum', enum: PlanType })
  planType: PlanType;

  // Number of months for MONTH plans (1-60, Section 4/6). Null for trials.
  @Column({ type: 'int', nullable: true })
  months: number | null;

  @Column({ name: 'expiry_date', type: 'timestamptz', nullable: true })
  expiryDate: Date | null;

  @Column({ type: 'enum', enum: CustomerStatus, default: CustomerStatus.PENDING })
  status: CustomerStatus;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}
