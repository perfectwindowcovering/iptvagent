import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
} from 'typeorm';

export enum UserRole {
  BUSINESS = 'business',
  AGENT = 'agent',
  CUSTOMER = 'customer',
}

export enum UserStatus {
  ACTIVE = 'active',
  SUSPENDED = 'suspended',
}

// Section 2: Account Roles.
// - business: full control, created at first setup (seeded), not self-registered.
// - agent: created only by a business account (see UsersService.createAgent).
// - customer: created automatically when an agent adds a customer whose
//   subscription is approved (see SubscriptionRequestsService).
@Entity('users')
export class User {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'enum', enum: UserRole })
  role: UserRole;

  // For agents: the business that owns them. Null for the business account itself.
  @ManyToOne(() => User, { nullable: true })
  @JoinColumn({ name: 'business_id' })
  business: User | null;

  @Column({ name: 'business_id', type: 'uuid', nullable: true })
  @Index()
  businessId: string | null;

  @Column({ unique: true })
  phone: string;

  @Column({ nullable: true, unique: true })
  email: string | null;

  @Column({ nullable: true })
  name: string | null;

  // Hashed with bcrypt only — see Section 11.1. Never store or return plain text.
  @Column({ name: 'password_hash' })
  passwordHash: string;

  @Column({ type: 'enum', enum: UserStatus, default: UserStatus.ACTIVE })
  status: UserStatus;

  // Section 11.1: mandatory 2FA for business and agent accounts.
  @Column({ name: 'two_factor_enabled', default: false })
  twoFactorEnabled: boolean;

  @Column({ name: 'two_factor_secret', nullable: true, select: false })
  twoFactorSecret: string | null;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}
