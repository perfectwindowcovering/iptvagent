import { Body, Controller, Get, Param, Patch, Post, Req, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { RolesGuard } from '../auth/roles.guard';
import { Roles } from '../auth/roles.decorator';
import { UserRole, UserStatus } from './user.entity';
import { UsersService } from './users.service';
import { CreateAgentDto } from './dto/create-agent.dto';

interface AuthedRequest {
  user: { id: string; role: UserRole; businessId: string | null };
}

// Every route here requires the BUSINESS role — Section 2.1: only the
// business account creates and manages agents.
@Controller('users/agents')
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles(UserRole.BUSINESS)
export class UsersController {
  constructor(private usersService: UsersService) {}

  @Post()
  create(@Req() req: AuthedRequest, @Body() dto: CreateAgentDto) {
    return this.usersService.createAgent(req.user.id, dto);
  }

  @Get()
  list(@Req() req: AuthedRequest) {
    return this.usersService.listAgentsForBusiness(req.user.id);
  }

  @Patch(':id/suspend')
  suspend(@Req() req: AuthedRequest, @Param('id') agentId: string) {
    return this.usersService.setAgentStatus(agentId, req.user.id, UserStatus.SUSPENDED);
  }

  @Patch(':id/reactivate')
  reactivate(@Req() req: AuthedRequest, @Param('id') agentId: string) {
    return this.usersService.setAgentStatus(agentId, req.user.id, UserStatus.ACTIVE);
  }
}
