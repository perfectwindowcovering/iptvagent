import { ConflictException, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User, UserRole, UserStatus } from './user.entity';
import { AuthService } from '../auth/auth.service';
import { CreateAgentDto } from './dto/create-agent.dto';

// Section 2.2: "Created only by a business account; cannot self-register."
// There is deliberately no public registration endpoint for agents —
// this is the only way an agent user row gets created.
@Injectable()
export class UsersService {
  constructor(@InjectRepository(User) private usersRepo: Repository<User>) {}

  async createAgent(businessId: string, dto: CreateAgentDto): Promise<User> {
    const existing = await this.usersRepo.findOne({ where: { phone: dto.phone } });
    if (existing) {
      throw new ConflictException('A user with this phone number already exists.');
    }

    const agent = this.usersRepo.create({
      role: UserRole.AGENT,
      businessId,
      name: dto.name,
      phone: dto.phone,
      email: dto.email ?? null,
      passwordHash: await AuthService.hashPassword(dto.temporaryPassword),
      status: UserStatus.ACTIVE,
    });
    return this.usersRepo.save(agent);
  }

  // Section 2.1: business can suspend/reactivate an agent account.
  async setAgentStatus(agentId: string, businessId: string, status: UserStatus): Promise<User> {
    const agent = await this.usersRepo.findOneOrFail({
      where: { id: agentId, role: UserRole.AGENT, businessId },
    });
    agent.status = status;
    return this.usersRepo.save(agent);
  }

  async listAgentsForBusiness(businessId: string): Promise<User[]> {
    return this.usersRepo.find({ where: { role: UserRole.AGENT, businessId } });
  }
}
