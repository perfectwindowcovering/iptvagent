import { IsString, IsOptional, IsEmail, MinLength } from 'class-validator';

export class CreateAgentDto {
  @IsString()
  name: string;

  @IsString()
  phone: string;

  @IsOptional()
  @IsEmail()
  email?: string;

  @IsString()
  @MinLength(8)
  temporaryPassword: string;
}
