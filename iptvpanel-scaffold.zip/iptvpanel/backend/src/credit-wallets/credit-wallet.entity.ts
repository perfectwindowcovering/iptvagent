import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  UpdateDateColumn,
  Unique,
} from 'typeorm';
import { User } from '../users/user.entity';
import { Server } from '../servers/server.entity';

// Section 7.1: each agent holds a SEPARATE credit balance per server,
// not one shared pool — since fixed rates can vary by server.
@Entity('agent_credit_wallets')
@Unique(['agent', 'server'])
export class AgentCreditWallet {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => User)
  @JoinColumn({ name: 'agent_id' })
  agent: User;

  @Column({ name: 'agent_id', type: 'uuid' })
  agentId: string;

  @ManyToOne(() => Server)
  @JoinColumn({ name: 'server_id' })
  server: Server;

  @Column({ name: 'server_id', type: 'uuid' })
  serverId: string;

  @Column({ type: 'decimal', precision: 10, scale: 2, default: 0 })
  balance: string;

  @UpdateDateColumn({ name: 'last_topup_date' })
  lastTopupDate: Date;
}
