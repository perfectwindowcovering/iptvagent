import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  CreateDateColumn,
} from 'typeorm';
import { AgentCreditWallet } from './credit-wallet.entity';

export enum CreditTransactionType {
  PURCHASE = 'purchase', // agent topped up via Stripe
  DEDUCTION = 'deduction', // auto-deducted on subscription approval
  MANUAL_ADJUSTMENT = 'manual_adjustment', // business-initiated credit/debit
}

@Entity('credit_transactions')
export class CreditTransaction {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => AgentCreditWallet)
  @JoinColumn({ name: 'wallet_id' })
  wallet: AgentCreditWallet;

  @Column({ name: 'wallet_id', type: 'uuid' })
  walletId: string;

  @Column({ type: 'enum', enum: CreditTransactionType })
  type: CreditTransactionType;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  amount: string;

  @Column({ name: 'related_request_id', type: 'uuid', nullable: true })
  relatedRequestId: string | null;

  @CreateDateColumn({ name: 'date' })
  date: Date;
}
