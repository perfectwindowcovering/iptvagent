import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SubscriptionRequest } from './subscription-request.entity';
import { Customer } from '../customers/customer.entity';
import { ServerPricing } from '../servers/server-pricing.entity';
import { AgentCreditWallet } from '../credit-wallets/credit-wallet.entity';
import { CreditTransaction } from '../credit-wallets/credit-transaction.entity';
import { Payment } from '../payments/payment.entity';
import { SubscriptionRequestsService } from './subscription-requests.service';
import { SubscriptionRequestsController } from './subscription-requests.controller';
import { PanelAdapterFactory } from '../servers/panel-adapters/panel-adapter.factory';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      SubscriptionRequest,
      Customer,
      ServerPricing,
      AgentCreditWallet,
      CreditTransaction,
      Payment,
    ]),
  ],
  providers: [SubscriptionRequestsService, PanelAdapterFactory],
  controllers: [SubscriptionRequestsController],
})
export class SubscriptionRequestsModule {}
