import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  CreateDateColumn,
  UpdateDateColumn,
} from 'typeorm';
import { User } from '../users/user.entity';
import { Customer, PlanType } from '../customers/customer.entity';

export enum RequestStatus {
  PENDING = 'pending',
  APPROVED = 'approved',
  REJECTED = 'rejected',
}

// Section 4: Core Workflow. Every trial/month activation goes through this
// queue and can only become ACTIVE after a business account approves it.
@Entity('subscription_requests')
export class SubscriptionRequest {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => Customer)
  @JoinColumn({ name: 'customer_id' })
  customer: Customer;

  @Column({ name: 'customer_id', type: 'uuid' })
  customerId: string;

  @ManyToOne(() => User)
  @JoinColumn({ name: 'requested_by' })
  requestedBy: User; // the agent

  @Column({ name: 'requested_by', type: 'uuid' })
  requestedById: string;

  @Column({ name: 'plan_type', type: 'enum', enum: PlanType })
  planType: PlanType;

  @Column({ type: 'int', nullable: true })
  months: number | null;

  // What the agent is charging the customer — may exceed the fixed rate
  // (Section 7: the difference becomes agent profit).
  @Column({ name: 'amount_charged', type: 'decimal', precision: 10, scale: 2 })
  amountCharged: string;

  @Column({ type: 'enum', enum: RequestStatus, default: RequestStatus.PENDING })
  status: RequestStatus;

  @ManyToOne(() => User, { nullable: true })
  @JoinColumn({ name: 'reviewed_by' })
  reviewedBy: User | null; // the business user who approved/rejected

  @Column({ name: 'reviewed_by', type: 'uuid', nullable: true })
  reviewedById: string | null;

  @Column({ name: 'rejection_reason', nullable: true })
  rejectionReason: string | null;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}
