import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { DataSource, Repository } from 'typeorm';
import { SubscriptionRequest, RequestStatus } from './subscription-request.entity';
import { Customer, CustomerStatus, PlanType } from '../customers/customer.entity';
import { ServerPricing } from '../servers/server-pricing.entity';
import { AgentCreditWallet } from '../credit-wallets/credit-wallet.entity';
import { CreditTransaction, CreditTransactionType } from '../credit-wallets/credit-transaction.entity';
import { Payment } from '../payments/payment.entity';
import { AuthService } from '../auth/auth.service';
import { PanelAdapterFactory } from '../servers/panel-adapters/panel-adapter.factory';
import { CreateSubscriptionRequestDto } from './dto/create-request.dto';

const EXPIRY_NOTICE_DAYS_BEFORE = 4; // Section 10.2: customer notice 4 days before expiry

@Injectable()
export class SubscriptionRequestsService {
  constructor(
    @InjectRepository(SubscriptionRequest) private requestsRepo: Repository<SubscriptionRequest>,
    @InjectRepository(Customer) private customersRepo: Repository<Customer>,
    @InjectRepository(ServerPricing) private pricingRepo: Repository<ServerPricing>,
    private dataSource: DataSource,
    private panelAdapterFactory: PanelAdapterFactory,
  ) {}

  // Section 4, step 1-3: agent submits a request; it enters Pending.
  async create(agentId: string, dto: CreateSubscriptionRequestDto): Promise<SubscriptionRequest> {
    let customer: Customer;

    if (dto.existingCustomerId) {
      customer = await this.customersRepo.findOneOrFail({
        where: { id: dto.existingCustomerId, agentId },
      });
    } else {
      customer = this.customersRepo.create({
        agentId,
        serverId: dto.serverId,
        name: dto.customerName,
        phone: dto.customerPhone,
        macAddress: dto.macAddress,
        // A temporary random password — the customer resets it (or the
        // agent shares it) once the subscription is approved.
        passwordHash: await AuthService.hashPassword(cryptoRandom()),
        planType: dto.planType,
        months: dto.months ?? null,
        status: CustomerStatus.PENDING,
      });
      customer = await this.customersRepo.save(customer);
    }

    const request = this.requestsRepo.create({
      customerId: customer.id,
      requestedById: agentId,
      planType: dto.planType,
      months: dto.months ?? null,
      amountCharged: dto.amountCharged,
      status: RequestStatus.PENDING,
    });
    return this.requestsRepo.save(request);
  }

  async listPendingForBusiness(): Promise<SubscriptionRequest[]> {
    return this.requestsRepo.find({
      where: { status: RequestStatus.PENDING },
      relations: ['customer', 'requestedBy'],
      order: { createdAt: 'ASC' },
    });
  }

  // Section 4, steps 4-6 + Section 7.1: the whole approval transaction.
  // Everything below happens atomically — either it all succeeds, or the
  // request stays Pending and nothing is charged/activated.
  async approve(requestId: string, businessUserId: string): Promise<SubscriptionRequest> {
    return this.dataSource.transaction(async (manager) => {
      const request = await manager.findOneOrFail(SubscriptionRequest, {
        where: { id: requestId, status: RequestStatus.PENDING },
        relations: ['customer', 'customer.server'],
      });
      const customer = request.customer;
      const server = customer.server;

      // 1. Look up the fixed rate for this server + duration (Section 6.2/7).
      const pricingKey = request.planType === PlanType.TRIAL ? 0 : (request.months ?? 0);
      const pricing = await manager.findOne(ServerPricing, {
        where: { serverId: server.id, months: pricingKey },
      });
      if (!pricing) {
        throw new BadRequestException(
          `No fixed rate configured for this server at ${pricingKey} month(s).`,
        );
      }
      const fixedRate = parseFloat(pricing.fixedRate);

      // 2. Deduct from the agent's per-server credit wallet (Section 7.1).
      if (fixedRate > 0) {
        const wallet = await manager.findOne(AgentCreditWallet, {
          where: { agentId: request.requestedById, serverId: server.id },
        });
        const balance = wallet ? parseFloat(wallet.balance) : 0;
        if (!wallet || balance < fixedRate) {
          // Section 13 open decision: here we block. Flip to "queue with
          // shortfall flagged" if you decide that's the preferred behavior.
          throw new BadRequestException(
            'Agent has insufficient credit on this server to cover the fixed rate.',
          );
        }
        wallet.balance = (balance - fixedRate).toFixed(2);
        await manager.save(wallet);
        await manager.save(
          manager.create(CreditTransaction, {
            walletId: wallet.id,
            type: CreditTransactionType.DEDUCTION,
            amount: fixedRate.toFixed(2),
            relatedRequestId: request.id,
          }),
        );
      }

      // 3. Create the actual login on the upstream IPTV panel (Section 6.4).
      // Swap the placeholder credentials decrypt with your real decryption.
      const decryptedCredentials = JSON.parse(server.apiCredentialsEncrypted);
      const adapter = this.panelAdapterFactory.create(server, decryptedCredentials);
      const panelResult = await adapter.createLogin({
        macAddress: customer.macAddress,
        months: request.months,
      });
      if (!panelResult.success) {
        throw new BadRequestException(`Panel login creation failed: ${panelResult.error}`);
      }

      // 4. Activate the customer and compute expiry.
      customer.status = CustomerStatus.ACTIVE;
      if (request.planType === PlanType.MONTH && request.months) {
        const expiry = new Date();
        expiry.setMonth(expiry.getMonth() + request.months);
        customer.expiryDate = expiry;
      }
      await manager.save(customer);

      // 5. Record the payment split (Section 7).
      const amountCharged = parseFloat(request.amountCharged);
      const agentProfit = Math.max(0, amountCharged - fixedRate);
      await manager.save(
        manager.create(Payment, {
          requestId: request.id,
          amount: amountCharged.toFixed(2),
          fixedPortion: fixedRate.toFixed(2),
          agentProfitPortion: agentProfit.toFixed(2),
          paymentMethod: 'wallet_credit',
        }),
      );

      // 6. Close out the request.
      request.status = RequestStatus.APPROVED;
      request.reviewedById = businessUserId;
      return manager.save(request);

      // NOTE: schedule the Section 10.2 expiry-notice job (4 days before
      // customer.expiryDate) from here, e.g. via a queue (BullMQ) keyed on
      // customer.id — kept out of this transaction since it's a side effect.
    });
  }

  async reject(requestId: string, businessUserId: string, reason: string): Promise<SubscriptionRequest> {
    const request = await this.requestsRepo.findOneOrFail({
      where: { id: requestId, status: RequestStatus.PENDING },
    });
    request.status = RequestStatus.REJECTED;
    request.reviewedById = businessUserId;
    request.rejectionReason = reason;
    return this.requestsRepo.save(request);
  }
}

function cryptoRandom(): string {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}
