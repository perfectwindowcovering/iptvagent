import { IsEnum, IsInt, IsNumberString, IsOptional, IsString, IsUUID, Max, Min } from 'class-validator';
import { PlanType } from '../../customers/customer.entity';

export class CreateSubscriptionRequestDto {
  // If omitted, a new customer is created alongside the request.
  @IsOptional()
  @IsUUID()
  existingCustomerId?: string;

  @IsString()
  customerName: string;

  @IsString()
  customerPhone: string;

  @IsString()
  macAddress: string;

  @IsUUID()
  serverId: string;

  @IsEnum(PlanType)
  planType: PlanType;

  // Section 4 / 6: up to 60 months.
  @IsOptional()
  @IsInt()
  @Min(1)
  @Max(60)
  months?: number;

  @IsNumberString()
  amountCharged: string;
}
