import { Body, Controller, Get, Param, Patch, Post, Req, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { RolesGuard } from '../auth/roles.guard';
import { Roles } from '../auth/roles.decorator';
import { UserRole } from '../users/user.entity';
import { SubscriptionRequestsService } from './subscription-requests.service';
import { CreateSubscriptionRequestDto } from './dto/create-request.dto';

interface AuthedRequest {
  user: { id: string; role: UserRole; businessId: string | null };
}

@Controller('subscription-requests')
@UseGuards(JwtAuthGuard, RolesGuard)
export class SubscriptionRequestsController {
  constructor(private service: SubscriptionRequestsService) {}

  // Section 4, step 1: only agents originate requests.
  @Roles(UserRole.AGENT)
  @Post()
  create(@Req() req: AuthedRequest, @Body() dto: CreateSubscriptionRequestDto) {
    return this.service.create(req.user.id, dto);
  }

  // Section 2.1: only business sees/approves the pending queue.
  @Roles(UserRole.BUSINESS)
  @Get('pending')
  listPending() {
    return this.service.listPendingForBusiness();
  }

  @Roles(UserRole.BUSINESS)
  @Patch(':id/approve')
  approve(@Req() req: AuthedRequest, @Param('id') id: string) {
    return this.service.approve(id, req.user.id);
  }

  @Roles(UserRole.BUSINESS)
  @Patch(':id/reject')
  reject(@Req() req: AuthedRequest, @Param('id') id: string, @Body('reason') reason: string) {
    return this.service.reject(id, req.user.id, reason);
  }
}
