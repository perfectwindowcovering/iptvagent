import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from 'typeorm';

export enum BoxStatus {
  ACTIVE = 'active',
  DISCONTINUED = 'discontinued',
}

// Section 8.4: master stock record, managed only by the business account.
@Entity('box_inventory')
export class BoxInventory {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ unique: true })
  sku: string;

  @Column({ name: 'model_name' })
  modelName: string;

  @Column({ name: 'cost_price', type: 'decimal', precision: 10, scale: 2 })
  costPrice: string;

  @Column({ name: 'agent_price', type: 'decimal', precision: 10, scale: 2 })
  agentPrice: string;

  @Column({ name: 'quantity_on_hand', type: 'int', default: 0 })
  quantityOnHand: number;

  @Column({ name: 'reorder_threshold', type: 'int', default: 5 })
  reorderThreshold: number;

  @Column({ type: 'enum', enum: BoxStatus, default: BoxStatus.ACTIVE })
  status: BoxStatus;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}
