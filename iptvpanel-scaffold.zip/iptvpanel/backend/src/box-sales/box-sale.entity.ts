import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  CreateDateColumn,
} from 'typeorm';
import { BoxInventory } from '../box-inventory/box-inventory.entity';
import { User } from '../users/user.entity';

// Section 8.4: recorded when an agent sells a box directly from stock.
// Feeds into the agent's sales/profit view alongside subscription sales.
@Entity('box_sales')
export class BoxSale {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => BoxInventory)
  @JoinColumn({ name: 'box_id' })
  box: BoxInventory;

  @Column({ name: 'box_id', type: 'uuid' })
  boxId: string;

  @ManyToOne(() => User)
  @JoinColumn({ name: 'agent_id' })
  agent: User;

  @Column({ name: 'agent_id', type: 'uuid' })
  agentId: string;

  @Column({ name: 'customer_name' })
  customerName: string;

  @Column()
  phone: string;

  @Column({ name: 'sale_price', type: 'decimal', precision: 10, scale: 2 })
  salePrice: string;

  @CreateDateColumn({ name: 'sale_date' })
  saleDate: Date;
}
