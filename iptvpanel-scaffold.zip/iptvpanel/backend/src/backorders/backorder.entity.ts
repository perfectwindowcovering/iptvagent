import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  CreateDateColumn,
} from 'typeorm';
import { BoxInventory } from '../box-inventory/box-inventory.entity';
import { User } from '../users/user.entity';

export enum BackorderStatus {
  PENDING = 'pending',
  FULFILLED = 'fulfilled',
  CANCELLED = 'cancelled',
}

// Section 8.3: created when an agent tries to sell an out-of-stock box.
// Matched against new stock (oldest first) when the business logs a
// restock — see BackordersService.matchAgainstNewStock().
@Entity('backorders')
export class Backorder {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => BoxInventory)
  @JoinColumn({ name: 'box_id' })
  box: BoxInventory;

  @Column({ name: 'box_id', type: 'uuid' })
  boxId: string;

  @ManyToOne(() => User)
  @JoinColumn({ name: 'agent_id' })
  agent: User;

  @Column({ name: 'agent_id', type: 'uuid' })
  agentId: string;

  @Column({ name: 'customer_name' })
  customerName: string;

  @Column()
  phone: string;

  @Column({ type: 'int', default: 1 })
  quantity: number;

  @Column({ type: 'enum', enum: BackorderStatus, default: BackorderStatus.PENDING })
  status: BackorderStatus;

  @CreateDateColumn({ name: 'requested_date' })
  requestedDate: Date;

  @Column({ name: 'fulfilled_date', type: 'timestamptz', nullable: true })
  fulfilledDate: Date | null;
}
