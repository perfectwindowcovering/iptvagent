import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ThrottlerModule } from '@nestjs/throttler';
import { AuthModule } from './auth/auth.module';
import { UsersModule } from './users/users.module';
import { SubscriptionRequestsModule } from './subscription-requests/subscription-requests.module';

import { User } from './users/user.entity';
import { Server } from './servers/server.entity';
import { ServerPricing } from './servers/server-pricing.entity';
import { Customer } from './customers/customer.entity';
import { SubscriptionRequest } from './subscription-requests/subscription-request.entity';
import { Payment } from './payments/payment.entity';
import { AgentCreditWallet } from './credit-wallets/credit-wallet.entity';
import { CreditTransaction } from './credit-wallets/credit-transaction.entity';
import { BoxInventory } from './box-inventory/box-inventory.entity';
import { BoxSale } from './box-sales/box-sale.entity';
import { Backorder } from './backorders/backorder.entity';
import { SetupGuide } from './setup-guides/setup-guide.entity';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    ThrottlerModule.forRoot([{ ttl: 60_000, limit: 100 }]), // Section 11.1 baseline rate-limit
    TypeOrmModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        type: 'postgres',
        host: config.get('DB_HOST'),
        port: config.get<number>('DB_PORT'),
        username: config.get('DB_USERNAME'),
        password: config.get('DB_PASSWORD'),
        database: config.get('DB_DATABASE'),
        entities: [
          User,
          Server,
          ServerPricing,
          Customer,
          SubscriptionRequest,
          Payment,
          AgentCreditWallet,
          CreditTransaction,
          BoxInventory,
          BoxSale,
          Backorder,
          SetupGuide,
        ],
        synchronize: false,
        // Section 11.3: encrypt sensitive columns at rest — add a TypeORM
        // transformer on Server.apiCredentialsEncrypted, or use pgcrypto.
      }),
    }),
    AuthModule,
    UsersModule,
    SubscriptionRequestsModule,
    // Add remaining feature modules the same way as they're built out:
    // ServersModule, CustomersModule, CreditWalletsModule, BoxInventoryModule,
    // BoxSalesModule, BackordersModule, SetupGuidesModule, PaymentsModule.
  ],
})
export class AppModule {}
