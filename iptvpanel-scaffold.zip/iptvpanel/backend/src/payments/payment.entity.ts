import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  CreateDateColumn,
} from 'typeorm';
import { SubscriptionRequest } from '../subscription-requests/subscription-request.entity';

// Section 7: on approval, payment is split — a fixed portion to the
// business, and anything above it credited to the agent as profit.
@Entity('payments')
export class Payment {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => SubscriptionRequest)
  @JoinColumn({ name: 'request_id' })
  request: SubscriptionRequest;

  @Column({ name: 'request_id', type: 'uuid' })
  requestId: string;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  amount: string;

  @Column({ name: 'fixed_portion', type: 'decimal', precision: 10, scale: 2 })
  fixedPortion: string;

  @Column({ name: 'agent_profit_portion', type: 'decimal', precision: 10, scale: 2 })
  agentProfitPortion: string;

  @Column({ name: 'payment_method' })
  paymentMethod: string; // e.g. 'wallet_credit', 'stripe', 'bank_transfer'

  @CreateDateColumn({ name: 'date' })
  date: Date;
}
