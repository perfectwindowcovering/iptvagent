import 'dotenv/config';
import { DataSource } from 'typeorm';
import { User } from './users/user.entity';
import { Server } from './servers/server.entity';
import { ServerPricing } from './servers/server-pricing.entity';
import { Customer } from './customers/customer.entity';
import { SubscriptionRequest } from './subscription-requests/subscription-request.entity';
import { Payment } from './payments/payment.entity';
import { AgentCreditWallet } from './credit-wallets/credit-wallet.entity';
import { CreditTransaction } from './credit-wallets/credit-transaction.entity';
import { BoxInventory } from './box-inventory/box-inventory.entity';
import { BoxSale } from './box-sales/box-sale.entity';
import { Backorder } from './backorders/backorder.entity';
import { SetupGuide } from './setup-guides/setup-guide.entity';

export const AppDataSource = new DataSource({
  type: 'postgres',
  host: process.env.DB_HOST,
  port: parseInt(process.env.DB_PORT ?? '5432', 10),
  username: process.env.DB_USERNAME,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_DATABASE,
  entities: [
    User,
    Server,
    ServerPricing,
    Customer,
    SubscriptionRequest,
    Payment,
    AgentCreditWallet,
    CreditTransaction,
    BoxInventory,
    BoxSale,
    Backorder,
    SetupGuide,
  ],
  migrations: ['src/migrations/*.ts'],
  synchronize: false, // use migrations in every environment beyond local prototyping
});
