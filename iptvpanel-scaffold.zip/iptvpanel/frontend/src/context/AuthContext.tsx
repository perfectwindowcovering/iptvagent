import { createContext, useContext, useState, ReactNode } from 'react';
import { api, setAccessToken } from '../api/client';

export type UserRole = 'business' | 'agent' | 'customer';

interface AuthState {
  role: UserRole | null;
  login: (phone: string, password: string, twoFactorCode?: string) => Promise<'2fa_required' | 'ok'>;
  logout: () => void;
}

const AuthContext = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [role, setRole] = useState<UserRole | null>(null);

  async function login(phone: string, password: string, twoFactorCode?: string) {
    const { data } = await api.post('/auth/login', { phone, password, twoFactorCode });
    if (data.twoFactorRequired) return '2fa_required' as const;

    setAccessToken(data.accessToken);
    // Decode role out of the JWT payload rather than a second round trip.
    const payload = JSON.parse(atob(data.accessToken.split('.')[1]));
    setRole(payload.role);
    return 'ok' as const;
  }

  function logout() {
    setAccessToken(null);
    setRole(null);
  }

  return <AuthContext.Provider value={{ role, login, logout }}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
