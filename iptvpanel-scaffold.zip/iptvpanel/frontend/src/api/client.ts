import axios from 'axios';

// Section 11.1: access tokens are short-lived (15m) — store in memory, not
// localStorage, to reduce exposure to XSS. Refresh token handling (silent
// refresh via an httpOnly cookie, ideally) should replace this simple
// in-memory approach before going to production.
let accessToken: string | null = null;

export function setAccessToken(token: string | null) {
  accessToken = token;
}

export const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL ?? 'http://localhost:3000/api',
});

api.interceptors.request.use((config) => {
  if (accessToken) {
    config.headers.Authorization = `Bearer ${accessToken}`;
  }
  return config;
});

api.interceptors.response.use(
  (res) => res,
  (error) => {
    if (error.response?.status === 401) {
      setAccessToken(null);
      window.location.href = '/login';
    }
    return Promise.reject(error);
  },
);
