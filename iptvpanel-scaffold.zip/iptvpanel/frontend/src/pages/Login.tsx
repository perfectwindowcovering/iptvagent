import { FormEvent, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

// One login screen for business, agent, and customer accounts (Section 2/3)
// — the backend decides the role from the phone number on file, so the
// frontend just routes based on what /auth/login returns.
export default function Login() {
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [twoFactorCode, setTwoFactorCode] = useState('');
  const [needsTwoFactor, setNeedsTwoFactor] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const { login } = useAuth();
  const navigate = useNavigate();

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const result = await login(phone, password, needsTwoFactor ? twoFactorCode : undefined);
      if (result === '2fa_required') {
        setNeedsTwoFactor(true);
      } else {
        navigate('/dashboard');
      }
    } catch (err: any) {
      setError(err?.response?.data?.message ?? 'Login failed. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={styles.page}>
      <form style={styles.card} onSubmit={handleSubmit}>
        <h1 style={styles.title}>IPTVPANEL</h1>
        <p style={styles.subtitle}>Sign in to your account</p>

        <label style={styles.label}>Phone number</label>
        <input
          style={styles.input}
          type="tel"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          required
          disabled={needsTwoFactor}
        />

        <label style={styles.label}>Password</label>
        <input
          style={styles.input}
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          disabled={needsTwoFactor}
        />

        {needsTwoFactor && (
          <>
            <label style={styles.label}>2FA code</label>
            <input
              style={styles.input}
              type="text"
              inputMode="numeric"
              value={twoFactorCode}
              onChange={(e) => setTwoFactorCode(e.target.value)}
              placeholder="6-digit code"
              autoFocus
              required
            />
          </>
        )}

        {error && <p style={styles.error}>{error}</p>}

        <button style={styles.button} type="submit" disabled={loading}>
          {loading ? 'Signing in…' : needsTwoFactor ? 'Verify' : 'Sign In'}
        </button>
      </form>
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  page: {
    minHeight: '100vh',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    background: '#111111',
    fontFamily: 'system-ui, sans-serif',
  },
  card: {
    background: '#ffffff',
    borderRadius: 12,
    padding: '40px 36px',
    width: 340,
    boxShadow: '0 20px 60px rgba(0,0,0,0.4)',
    borderTop: '4px solid #B00020',
  },
  title: { margin: 0, fontSize: 24, color: '#111111', letterSpacing: 1 },
  subtitle: { marginTop: 4, marginBottom: 24, color: '#666666', fontSize: 14 },
  label: { display: 'block', fontSize: 13, color: '#333333', marginBottom: 6, marginTop: 14 },
  input: {
    width: '100%',
    padding: '10px 12px',
    borderRadius: 6,
    border: '1px solid #cccccc',
    fontSize: 14,
    boxSizing: 'border-box',
  },
  button: {
    width: '100%',
    marginTop: 24,
    padding: '12px',
    borderRadius: 6,
    border: 'none',
    background: '#B00020',
    color: '#ffffff',
    fontWeight: 600,
    fontSize: 15,
    cursor: 'pointer',
  },
  error: { color: '#B00020', fontSize: 13, marginTop: 12 },
};
