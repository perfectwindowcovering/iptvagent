import { useAuth } from '../context/AuthContext';

// Placeholder landing screen — swap each branch for the real dashboard
// (business: approvals/CRM/reporting; agent: add-login/CRM/wallet;
// customer: player app) as those modules are built.
export default function Dashboard() {
  const { role, logout } = useAuth();

  return (
    <div style={{ fontFamily: 'system-ui, sans-serif', padding: 32 }}>
      <h1 style={{ color: '#111111' }}>
        IPTVPANEL — <span style={{ color: '#B00020' }}>{role}</span> dashboard
      </h1>
      {role === 'business' && <p>Pending approvals, agents, servers, and reporting go here.</p>}
      {role === 'agent' && <p>Add Login, CRM, credit wallets, and profit view go here.</p>}
      {role === 'customer' && <p>The Player App view goes here.</p>}
      <button onClick={logout}>Log out</button>
    </div>
  );
}
