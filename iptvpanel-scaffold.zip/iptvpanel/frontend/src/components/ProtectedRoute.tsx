import { Navigate } from 'react-router-dom';
import { ReactNode } from 'react';
import { useAuth } from '../context/AuthContext';

// Frontend-side gating for UX only — the real enforcement is the backend's
// RolesGuard (Section 11.2). Never rely on this alone.
export default function ProtectedRoute({ children }: { children: ReactNode }) {
  const { role } = useAuth();
  if (!role) return <Navigate to="/login" replace />;
  return <>{children}</>;
}
