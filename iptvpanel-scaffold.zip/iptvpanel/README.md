# IPTVPANEL

Business / Agent / Customer platform for IPTV subscription resale, box sales,
and streaming — implemented from the project's functional specification.

This is a working foundation, not a finished product: the approval workflow,
auth/RBAC system, and data model are fully implemented. Panel API integration
(Xtream Codes / Stalker-Ministra), Stripe, 2FA, and the remaining CRUD
modules (servers, box inventory, backorders, setup guides) are stubbed with
clear `TODO`-style errors marking exactly what to fill in — see "What's next"
below.

## Stack

- **Backend:** Node.js, NestJS, TypeORM, PostgreSQL — see Section 12 of the spec
- **Frontend:** React (Vite), TypeScript, React Router
- **Mobile (not yet scaffolded):** React Native, sharing types/logic with the frontend

## Project layout

```
iptvpanel/
  backend/
    src/
      auth/                     # login, JWT, 2FA hook, roles guard (Section 11)
      users/                    # business creates agents (Section 2.2)
      servers/                  # server entity, pricing, panel adapters (Section 6)
      customers/                # customer entity (Sections 2.3, 3, 4)
      subscription-requests/    # the core approval workflow (Section 4)
      payments/                 # payment split records (Section 7)
      credit-wallets/           # per-server agent wallets (Section 7.1)
      box-inventory/            # box stock (Section 8)
      box-sales/                # box sales (Section 8)
      backorders/               # backorder queue (Section 8.3)
      setup-guides/             # PDF setup guide library (Section 9)
      app.module.ts
      main.ts
      data-source.ts            # TypeORM CLI config (for migrations)
      scripts/seed-business.ts  # creates the first business login
  frontend/
    src/
      pages/Login.tsx           # single login screen for all 3 roles
      pages/Dashboard.tsx       # role-gated placeholder
      context/AuthContext.tsx
      api/client.ts
```

## Getting started

### Prerequisites

- Node.js 20+
- PostgreSQL 15+ running locally or accessible remotely

### Backend

```bash
cd backend
npm install
cp .env.example .env        # fill in DB credentials, JWT secrets, Stripe keys
```

Create the database tables. This scaffold ships with entities but no
migration files yet — generate the first one against your running Postgres
instance:

```bash
npm run migration:generate -- src/migrations/InitialSchema
npm run migration:run
```

Create the first business login (there is no public signup — Section 2.1):

```bash
SEED_BUSINESS_PHONE="+10000000000" SEED_BUSINESS_PASSWORD="ChangeMe123!" \
  npx ts-node src/scripts/seed-business.ts
```

Run the API:

```bash
npm run start:dev
```

The API listens on `http://localhost:3000/api`.

### Frontend

```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```

Open `http://localhost:5173`.

## What's next

Roughly in the order it'll unblock the most:

1. **Panel adapters** (`backend/src/servers/panel-adapters/`) — replace the
   `XtreamCodesAdapter` / `StalkerMinistraAdapter` stubs with real calls to
   your upstream IPTV panel APIs. Everything else (approval workflow,
   customer player app) is already built against this interface.
2. **2FA** — plug `otplib` (or similar) into `AuthService.verifyTwoFactorCode`,
   plus an enrollment endpoint that generates/stores `twoFactorSecret`.
3. **Servers module** — CRUD controller for adding/editing servers and their
   pricing (entities already exist: `Server`, `ServerPricing`).
4. **Stripe integration** (Section 10.10) — credit wallet top-ups
   (`AgentCreditWallet`) via Stripe Checkout/PaymentIntents, plus a webhook
   handler that credits the wallet on successful payment.
5. **Box inventory, box sales, backorders, setup guides** — CRUD modules
   following the same pattern as `SubscriptionRequestsModule`.
6. **Expiry notice job** (Section 10.2) — a scheduled job (e.g. BullMQ or
   `@nestjs/schedule`) that finds customers expiring in 4 days and sends
   the notice; hook point is called out in
   `SubscriptionRequestsService.approve()`.
7. **Encryption at rest** for `Server.apiCredentialsEncrypted` (Section 11.3)
   — currently stored as plain JSON; add a TypeORM column transformer or
   `pgcrypto`.
8. **Customer Player App** (Section 3) — separate React Native app; reuses
   the same `/auth/login` endpoint and the panel-adapter layer for stream
   resolution.
9. **React Native agent/business app** (Section 12.3) — once the web
   dashboards are fleshed out, share the API client and types.

## Security notes

See Section 11 of the spec for the full reasoning. Highlights already wired
into this scaffold:

- Passwords: bcrypt, 12 rounds
- JWT access tokens: short-lived (15m default), separate refresh token
- Rate-limiting: global Throttler + per-account lockout after 5 failed logins
- RBAC: enforced server-side via `RolesGuard`, never left to the frontend
- Helmet + strict CORS + global `ValidationPipe` (`whitelist`,
  `forbidNonWhitelisted`) on every request

Still to add before production: TLS termination/HSTS at the infra level,
secrets manager instead of `.env` in production, WAF (e.g. Cloudflare) in
front of the app, and a scheduled penetration test — all flagged in Section
11.4/11.5 and Section 13's open decisions.
